sudo apt-get update
sudo apt-get install default-jdk -y
sudo apt-get install default-jre -y
sudo apt-get install docker.io –y
