from scheduler import run_predictor, run_cost_saver
import time

if __name__ == "__main__":
    while True:
        run_predictor()
        run_cost_saver()
        time.sleep(60)  # run every hour
