## 🧰 Prerequisites
- Docker (with access to the same runtime used by Kubernetes, e.g. Rancher Desktop or Minikube)
- Kubernetes cluster (local preferred)
- `kubectl` configured to your cluster context



## Deploy Kube State Metric
kubectl apply -k ksm/


## Deploy Cadvisor
kubectl apply -k cadvisor/



## Deploy Prometheus
kubectl apply -k prometheus/


## Deploy Pushgateway
kubectl apply -k pushgateway/


## Deploy Grafana
kubectl apply -k grafana/*.yaml
- visit - http://localhost:32000/
- import template.json in UI




## Build and Deploy a ML service
cd ml-service
docker build . -t ml-service
kubectl apply -f deployment.yaml

- Verify logs



## Build and Deploy a sample app
cd sample_app
docker build -t sample-html-app:local .
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl get service sample-html-service

- Verify on - http://localhost:31999