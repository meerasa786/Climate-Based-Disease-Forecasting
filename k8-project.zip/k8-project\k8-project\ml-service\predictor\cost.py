def push_prediction(prediction_values, job_name="resource-predictor", label_name="default", cpu_limit=None):
    registry = CollectorRegistry()

    # Predicted usage (millicores)
    g = Gauge('predicted_cpu_usage', 'Forecasted CPU usage', ['timestamp', 'target'], registry=registry)
    for i, value in enumerate(prediction_values):
        g.labels(timestamp=f"t+{i*5}m", target=label_name).set(value)

    # Predicted cost
    total_cost = calculate_predicted_cost(prediction_values)
    cost_gauge = Gauge('predicted_cpu_cost', 'Estimated cost from predicted CPU usage', ['target'], registry=registry)
    cost_gauge.labels(target=label_name).set(total_cost)

    # Estimated savings (if CPU limit > usage)
    if cpu_limit:
        average_predicted = sum(prediction_values) / len(prediction_values)
        if cpu_limit > average_predicted:
            saved = (cpu_limit - average_predicted) * 1.6 * 1  # ₹1.6/hr × 1h
        else:
            saved = 0
        save_gauge = Gauge('predicted_cpu_cost_saved', 'Estimated cost savings from right-sizing', ['target'], registry=registry)
        save_gauge.labels(target=label_name).set(saved)

    push_to_gateway(PUSHGATEWAY_URL, job=job_name, registry=registry)
    print(f"✅ Pushed prediction, cost ₹{total_cost:.2f}, saved ₹{saved:.2f} for {label_name}")
