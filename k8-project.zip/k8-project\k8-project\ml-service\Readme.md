# 📈 Kubernetes Resource Predictor

This is a modular Python service designed to analyze historical resource usage data (CPU, memory, etc.) from Prometheus and predict future resource needs using basic time-series techniques like linear regression.

The predictions can help with right-sizing pods, detecting capacity issues early, and optimizing cluster scaling.

---

## 🚀 Features

- Reads real-time time-series metrics from Prometheus
- Performs historical trend analysis (e.g., CPU usage over time)
- Predicts future usage using linear regression
- (Optional) Pushes results to Prometheus Pushgateway
- Modular and extensible design for adding LSTM/Prophet models

---

## 🧰 Requirements

- Python 3.9+
- Prometheus (with metrics like `container_cpu_usage_seconds_total`)
- Prometheus Pushgateway (optional, for writing predictions back)



# Create a Virtual Environment
python3 -m venv venv
source venv/bin/activate


#  Install Dependencies
pip install -r requirements.txt


# run the server
python main.py


## Use docker
docker build . -t ml-service


## 