from datetime import datetime, timedelta, timezone
from client.prometheus_client import query_range, push_prediction, query_instant, push_cost_saved
from predictor.preprocessing import to_dataframe
from predictor.trend_model import predict_linear
from datetime import datetime, timedelta, timezone
import statistics

def run_predictor():
    try:
        # Use UTC and format in RFC 3339 (Prometheus expects this)
        now = datetime.now(timezone.utc)
        past = now - timedelta(days=2)

        # Format start and end timestamps
        end_time = now.strftime("%Y-%m-%dT%H:%M:%SZ")
        start_time = past.strftime("%Y-%m-%dT%H:%M:%SZ")

        print(f"Fetching data from {start_time} to {end_time}")

        # Use rate() to get usable time-series data
        promql_query = 'rate(container_cpu_usage_seconds_total[5m])'

        data = query_range(promql_query, start=start_time, end=end_time, step="300s")

        df = to_dataframe(data)

        if df.empty:
            print("No data received for the given time range.")
            return

        for series in data:
            metric_labels = series.get("metric", {})
            values = series.get("values", [])

            if not values:
                continue

            # Convert to DataFrame
            df = to_dataframe([series])  # wrap single series

            if df.empty:
                continue

            prediction = predict_linear(df)

            # Construct label for pushgateway
            container = metric_labels.get("container_label_io_kubernetes_container_name", "unknown")
            pod = metric_labels.get("container_label_io_kubernetes_pod_name", "unknown")
            namespace = metric_labels.get("container_label_io_kubernetes_pod_namespace", "unknown")

            if pod == "unknown" or container == "unknown":
                print("Skipping unknown pod/container")
                continue

            label = f"{namespace}/{pod}/{container}"
            print(f"📈 Predicting for: {label}")
            print("→ Prediction:", prediction)
            prediction = [p * 1000 for p in prediction]

            push_prediction(prediction_values=prediction, job_name="resource-predictor", label_name=label)

    except Exception as e:
        print(f"❌ Error in run_predictor: {e}")



def run_cost_saver():
    # Step 1: Get CPU limits (cores)
    alloc_data = query_instant('kube_pod_container_resource_limits{resource="cpu",unit="core"}')
    alloc_map = {}
    for item in alloc_data:
        metric = item.get("metric", {})
        namespace = metric.get("namespace")
        pod = metric.get("pod")
        container = metric.get("container")

        if namespace and pod and container:
            key = f"{namespace}/{pod}/{container}"
            value = float(item["value"][1])
            alloc_map[key] = value


    # Step 2: Get recent CPU usage (rate over 5m)
    usage_data = query_instant('rate(container_cpu_usage_seconds_total[5m])')
    usage_map = {
        m['metric'].get('target') or
        f"{m['metric'].get('container_label_io_kubernetes_pod_namespace')}/"
        f"{m['metric'].get('container_label_io_kubernetes_pod_name')}/"
        f"{m['metric'].get('container_label_io_kubernetes_container_name')}":
        float(m['value'][1])
        for m in usage_data
    }

    # Step 3: Compare and push cost saved
    for target in alloc_map:
        if target in usage_map:
            push_cost_saved(
                target=target,
                allocated=alloc_map[target],
                usage=usage_map[target]
            )
