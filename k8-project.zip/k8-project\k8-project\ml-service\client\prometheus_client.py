import requests

from config import PROMETHEUS_URL
from prometheus_client import CollectorRegistry, Gauge, push_to_gateway
from config import PUSHGATEWAY_URL, COST_PER_CORE_PER_HOUR

def query_range(metric_name, start, end, step):
    response = requests.get(f"{PROMETHEUS_URL}/api/v1/query_range", params={
        "query": metric_name,
        "start": start,
        "end": end,
        "step": step
    })
    return response.json()["data"]["result"]


def query_instant(metric_name):
    from config import PROMETHEUS_URL
    import requests

    url = f"{PROMETHEUS_URL}/api/v1/query"
    params = {"query": metric_name}
    response = requests.get(url, params=params).json()

    if response.get("status") != "success":
        print(f"Failed to fetch metric: {metric_name}")
        return []

    return response["data"]["result"]



def push_prediction(prediction_values, job_name="resource-predictor", label_name="default"):
    registry = CollectorRegistry()
    g = Gauge('predicted_cpu_usage', 'Forecasted CPU usage', ['timestamp', 'target'], registry=registry)

    for i, value in enumerate(prediction_values):
        g.labels(timestamp=f"t+{i*5}m", target=label_name).set(value)


    push_to_gateway(PUSHGATEWAY_URL, job=job_name, registry=registry)
    print(f"✅ Pushed prediction for {label_name}")



def push_cost_saved(target, allocated, usage, hours=1):
    registry = CollectorRegistry()
    saved = max((allocated - usage) * COST_PER_CORE_PER_HOUR * hours, 0)

    g = Gauge("predicted_cpu_cost_saved", "Estimated cost savings from right-sizing CPU", ["target"], registry=registry)
    g.labels(target=target).set(saved)

    push_to_gateway(PUSHGATEWAY_URL, job="resource-predictor", registry=registry)
    print(f"✅ Cost saved pushed: {target} → ₹{round(saved, 2)}")
