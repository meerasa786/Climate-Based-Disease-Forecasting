import pandas as pd
from datetime import datetime

def to_dataframe(prom_data):
    if not prom_data:
        return pd.DataFrame()
    values = prom_data[0]["values"]
    df = pd.DataFrame(values, columns=["timestamp", "value"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="s")
    df["value"] = pd.to_numeric(df["value"])
    return df.set_index("timestamp")
