# PROMETHEUS_URL = "http://localhost:30900"
PROMETHEUS_URL = "http://prometheus.monitoring.svc.cluster.local:9090"
# PUSHGATEWAY_URL = "http://localhost:30991"
PUSHGATEWAY_URL = "http://pushgateway.monitoring.svc.cluster.local:9091"
SCRAPE_INTERVAL = "5m"
LOOKBACK_RANGE = "2d"  # how far to look back
COST_PER_CORE_PER_HOUR = 0.005 # USD for cost calculation