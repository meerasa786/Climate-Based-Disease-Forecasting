from sklearn.linear_model import LinearRegression
import numpy as np
import pandas as pd

def predict_linear(df: pd.DataFrame, horizon_minutes=10):
    df = df.asfreq('5min')  # match your scrape interval
    df = df.ffill()
    df["t"] = np.arange(len(df))
    model = LinearRegression().fit(df[["t"]], df["value"])
    future_t = np.arange(len(df), len(df) + horizon_minutes // 5)
    pred = model.predict(future_t.reshape(-1, 1))
    return pred
